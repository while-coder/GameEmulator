/* FCE Ultra - NES/Famicom Emulator: 3933
 *
 * Copyright notice for this file:
 *  Copyright (C) 2026 NewRisingSun
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "mapinc.h"
#include "asic_latch.h"

static void sync () {
	setprg32(0x8000, Latch_address <<2 | Latch_data >>4 &0x03);
	setchr8(Latch_address <<2 | Latch_data &0x03);
	setmirror(Latch_address &0x04? MI_H: MI_V);
}

static void trapLatchWrite (uint16_t *newAddress, uint8_t *newValue, uint8_t romValue) {
	if (!(~Latch_address &0x20 && *newAddress &0x20)) *newAddress = Latch_address; /* Address bits only latched on a rising edge of A5 */
}

void Mapper639_Init (CartInfo *info) {
	Latch_init(info, sync, 0x8000, 0xFFFF, trapLatchWrite);
	info->Reset = Latch_clear;
}
